import java.util.ArrayList;
//Semir Bralić 23/050, Haris Sutović 24/084 > Projekat 1

public class Game {

	private Player player;
	private ArrayList<Enemy> enemies;
    private ArrayList<String> dnevnik;
    
    public Game(Player player) {
        this.player = player;
        enemies = new ArrayList<Enemy>();
        dnevnik = new ArrayList<String>();
    }
	
	public boolean checkCollision(Player p, Enemy e) {
		
		if (p.getX() < e.getX() + e.getWidth() && p.getX() + p.getWidth()> e.getX() && p.getY() < e.getY() + e.getHeight() && p.getY() + p.getHeight() > e.getY()) {
			
			return true;
		}
		
		return false;
	}
	
	public void decreaseHealth(Player p, Enemy e) {
		int stariHealth = p.getHealth();
		int noviHealth = stariHealth - e.getDamage();
		
		if (noviHealth < 0) {
			noviHealth = 0;
		}
		
		p.setHealth(noviHealth);
		
		String poruka = "Pogođen je " + p.getName() + " od strane " + e.getType() + " za količinu " + e.getDamage() + " dmg. Stari hp: "+ stariHealth + ". Novi Health: " + noviHealth;
		
		dnevnik.add(poruka);
	}
	
	public void addEnemy(Enemy e) {
		enemies.add(e);
		dnevnik.add("Dodan je neprijatelj: "+ e.getType());
		
	}
	
	public ArrayList<Enemy> findByType(String query) {
		
		ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
		
		for (int i = 0; i < enemies.size(); i++) {
			if(enemies.get(i).containsType(query)) {
				rezultat.add(enemies.get(i));
			}
		}
		
		return rezultat;
	}
	
	public ArrayList<Enemy> collidingWithPlayer() {

	    ArrayList<Enemy> rezultat = new ArrayList<Enemy>();

	    for (int i = 0; i < enemies.size(); i++) {

	        if (checkCollision(player, enemies.get(i))) {
	            rezultat.add(enemies.get(i));
	        }
	    }

	    return rezultat;
	}
	
	 public void resolveCollisions() {

	        ArrayList<Enemy> sudari = collidingWithPlayer();

	        for (int i = 0; i < sudari.size(); i++) {

	            decreaseHealth(player, sudari.get(i));
	        }
	    }

	 public void ispisiNeprijatelje() {
		 for (int i = 0; i<enemies.size();i++) {
			 System.out.println(enemies.get(i));
		 }
	}
	
	 public void ispisiDnevnik() {
		 System.out.println("Dnevnik Događaja");
		 
		 for (int i = 0; i < dnevnik.size(); i++) {
			 System.out.println(dnevnik.get(i));
		 }
	 }
	
	
	public static void main(String[] args) {

		Player player = new Player(" player 1 ", 10, 5, 32, 32, 85);
		
		Game game = new Game(player);
		
		Enemy e1 = new Enemy(" Haris Sutović ", 12, 5, 16, 16, 20);
		Enemy e2= new Enemy(" Semir Bralić ", 100, 100, 20,20,30);
		Enemy e3 = new Enemy(" Goblin ", 12, 5, 16, 16, 20);
		
		game.addEnemy(e1);
		game.addEnemy(e2);
		game.addEnemy(e3);
		
		System.out.println("Neprijatelji nacije: ");
		game.ispisiNeprijatelje();
		
		System.out.println();
		
		ArrayList<Enemy> goblini = game.findByType("gob");
		ArrayList<Enemy> neprijatelj = game.findByType("haris");
		
		for (int i = 0; i < goblini.size();i++) {
			System.out.println(goblini.get(i));
		}
		
		for (int i = 0; i < neprijatelj.size();i++) {
			System.out.println(neprijatelj.get(i));
		}
		
		System.out.println(); 
		
		System.out.println("Plejer prije sudara sa neprijateljom ");
		System.out.println(player);
		
		ArrayList<Enemy> sudari = game.collidingWithPlayer();

        System.out.println();
        System.out.println("NEPRIJATELJI U KOLIZIJI:");
       
        for (int i = 0; i < sudari.size(); i++) {
            System.out.println(sudari.get(i));
        }

        game.resolveCollisions();

        System.out.println();
        System.out.println("PLAYER POSLIJE KOLIZIJE:");
        System.out.println(player);

        System.out.println();

        game.ispisiDnevnik();
    }

}

