
class MeleeEnemy extends Enemy {

	public MeleeEnemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type, damage, health);
	}

	@Override
	public String toString() {
		return "MeleeEnemy [getHealth()=" + getHealth() + ", getType()=" + getType() + ", getDamage()=" + getDamage()
				+ ", toString()=" + super.toString() + ", getX()=" + getX() + ", getY()=" + getY() + ", getWidth()="
				+ getWidth() + ", getHeight()=" + getHeight() + ", getClass()=" + getClass() + "]";
	}
	
	
	
}
