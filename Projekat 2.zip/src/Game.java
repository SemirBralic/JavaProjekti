import java.util.ArrayList;
//Semir Bralić 23/050, Haris Sutović 24/084 > Projekat 1
//Sada je postalo samo Semir Bralić 23/050 > Projekat 2

public class Game {

	private Player player;
	private ArrayList<Enemy> enemies;
    private ArrayList<String> dnevnik;
    
    public Game(Player player) {
        this.player = player;
        enemies = new ArrayList<Enemy>();
        dnevnik = new ArrayList<String>();
    }
	
	public boolean checkCollision(Player p, Enemy e) {
		return p.intersects(e);
	}
	
	public void decreaseHealth(Player p, Enemy e) {
		int stariHealth = p.getHealth();
		int damage = e.getAttackDamage();
		int noviHealth = stariHealth - damage;
		
		if (noviHealth < 0) {
			noviHealth = 0;
			System.out.println("Umro si.");
		}
		
		p.setHealth(noviHealth);
		
		String poruka = "Pogođen je " + p.getName() + " od strane " + e.getType() + " za količinu " + e.getAttackDamage() + " dmg. Stari hp: "+ stariHealth + ". Novi Health: " + noviHealth;
		
		dnevnik.add(poruka);
	}
	
	public void addEnemy(Enemy e) {
		enemies.add(e);
		dnevnik.add("Dodan je neprijatelj: "+ e.getType());
		
	}
	
	public ArrayList<Enemy> findByType(String query) {
		
		ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
		
		for (int i = 0; i < enemies.size(); i++) {
			Enemy e = enemies.get(i);
			if (e.getType().toLowerCase().contains(query.toLowerCase())) {
				rezultat.add(e);
			}
		}
		
		return rezultat;
	}
	
	public ArrayList<Enemy> collidingWithPlayer() {
	    ArrayList<Enemy> rezultat = new ArrayList<Enemy>();
	    for (int i = 0; i < enemies.size(); i++) {
	        if (checkCollision(player, enemies.get(i))) {
	            rezultat.add(enemies.get(i));
	        }
	    }

	    return rezultat;
	}
	
	 public void resolveCollisions() {

	        ArrayList<Enemy> sudari = collidingWithPlayer();

	        for (int i = 0; i < sudari.size(); i++) {

	            decreaseHealth(player, sudari.get(i));
	        }
	    }

	 public void ispisiNeprijatelje() {
		 for (int i = 0; i<enemies.size();i++) {
			 System.out.println(enemies.get(i));
		 }
	}
	
	 public void ispisiDnevnik() {
		 System.out.println("Dnevnik Događaja");
		 
		 for (int i = 0; i < dnevnik.size(); i++) {
			 System.out.println(dnevnik.get(i));
		 }
	 }
	
	
	public static void main(String[] args) {

		Player player = new Player(32, 10, 5, 32, " player 1 ", 85);
		
		Game game = new Game(player);
		
		Enemy e1 = new Enemy(16, 10, 30, 40, "Goblin", 30, 140);
		BossEnemy boss = new BossEnemy(30, 15, 10, 40, "Boss", 50, 200);
		
		game.addEnemy(e1);
		game.addEnemy(boss);
		
		System.out.println("Neprijatelji nacije: ");
		game.ispisiNeprijatelje();
		
		System.out.println();
		
		ArrayList<Enemy> goblini = game.findByType("gob");
		ArrayList<Enemy> neprijatelj = game.findByType("haris");
		
		for (int i = 0; i < goblini.size();i++) {
			System.out.println(goblini.get(i));
		}
		
		for (int i = 0; i < neprijatelj.size();i++) {
			System.out.println(neprijatelj.get(i));
		}
		
		System.out.println(); 
		
		System.out.println("Plejer prije sudara sa neprijateljom ");
		System.out.println(player);
		
		ArrayList<Enemy> sudari = game.collidingWithPlayer();

        System.out.println();
        System.out.println("NEPRIJATELJI U KOLIZIJI:");
       
        for (int i = 0; i < sudari.size(); i++) {
            System.out.println(sudari.get(i));
        }

        game.resolveCollisions();

        System.out.println();
        System.out.println("PLAYER POSLIJE KOLIZIJE:");
        System.out.println(player);

        System.out.println();

        game.ispisiDnevnik();
    }

}

