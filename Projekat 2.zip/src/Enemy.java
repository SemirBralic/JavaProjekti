public class Enemy extends GameObject{

	private String type;
	private int damage;
	private int health;
	
	public Enemy(int x, int y, int width, int height, String type, int damage, int health) {
		super(x, y, width, height, type);
		this.type = type;
		this.damage = damage;
		this.health = health;
	}
	
	public int getHealth() { //oprostite što je kod malo naopak, popravljam ga da bi sadržao stvori sa novog projekta (koristim stari projekat i nadodajem na njega)
		return health;
	}

	public void setHealth(int health) {
		if (health < 0) {
			this.health = 0;
		} else if (health > 100) {
			this.health = 100;
		} else
			this.health = health;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		if(type!=null&&!type.trim().isEmpty()) {
			type = type.toLowerCase();
			type = type.substring(0,1).toUpperCase() + type.substring(1).toLowerCase();
		}
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		if (damage < 0) {
			this.damage = 0;
		} else if (damage > 100) {
			this.damage = 100;
		} else
			this.damage = damage;
	}
	
	public boolean containsType(String query) {
		return type.toLowerCase().contains(query.trim().toLowerCase());
	}


	public int getAttackDamage() {
		return damage;
	}
	
	@Override
	public String toString() {
		return "Enemy [type=" + type + ", damage=" + damage + ", health=" + health + ", getX()=" + getX() + ", getY()="
				+ getY() + ", getWidth()=" + getWidth() + ", getHeight()=" + getHeight() + ", toString()="
				+ super.toString() + ", getClass()=" + getClass() + "]";
	}
	
	
	
}
	
	
	

