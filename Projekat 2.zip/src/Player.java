public class Player extends GameObject{

	private String name;
	private int x;
	private int y;
	private int width;
	private int height;
	private int health;
	
	
	
	public Player(int x, int y, int width, int height, String name, int health) {
		super(x, y, width, height, "Player");
		this.name = name;
		this.health = health;
	}

	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		name = name.trim() ;
		
		String[] rijeci = name.split(" ");
		String novoIme="";
		
		for (int i = 0; i < rijeci.length; i++) {
			if(!rijeci[i].equals("")) {
				novoIme = novoIme + rijeci[i].substring(0,1).toUpperCase() + rijeci[i].substring(1).toLowerCase(); 				
			}
		}
		this.name = novoIme.trim();
	}
	
	public int getX() {
		return x;
	}
	
	public void setX(int x) {
		this.x = x;
	}
	
	public int getY() {
		return y;
	}
	
	public void setY(int y) {
		if (this.y > 0)
			this.y = y;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int width) {
		if (this.width > 0)
			this.width = width;
	}
	
	public int getHeight() {
		return height;
	}
	
	public void setHeight(int height) {
		if (this.height > 0)
			this.height = height;
	}
	
	public int getHealth() {
		return health;
	}
	
	public void setHealth(int health) {
		if (health < 0) {
			this.health = 0;
		} else if (health > 0) {
			this.health = 100;
		} else
			this.health = health;
	}

	@Override
	public String toString() {
		return "Player [" + name + "] @ (" + x + "," + y + ") " + width + "x" + height + " HP=" + health;
	}
	
}
