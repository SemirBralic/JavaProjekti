
public class GameObject {
	private int x,y;
	private int width, height;
	private String type;
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		if (this.width > 0)
			this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if (this.height > 0)
			this.height = height;
			
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		if(type!=null&&!type.trim().isEmpty())
			this.type = type.trim();
	}
	public GameObject(int x, int y, int width, int height, String type) {
		super();
		setX(x);
		setY(y);
		setWidth(width);
		setHeight(height);
		setType(type);
	}
	
	public boolean intersects(GameObject other) {
		if (x < other.getX() + other.getWidth() && x + width > other.getX() && y < other.getY() + other.getHeight() && y + height > other.getY()) {
			return true;
		}
		return false;
	}
	@Override
	public String toString() {
		return "GameObject @ (" + x + "," + y + "), " + width + "x" + height + ", type=" + type + "]";
	}
	
}